#ifndef __MYHASHTABLE_H__
#define __MYHASHTABLE_H__

#include <iostream>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <string>

#include "MyVector.h"
#include "MyLinkedList.h"

static const long long uh_param_a = 53;       // universal hash function parameter a
static const long long uh_param_b = 97;       // universal hash function parameter b
static const long long prime_digits = 19;     // parameter used for finding a Mersenne prime
static const long long mersenne_prime = (1 << prime_digits) - 1;  // the Mersenne prime for universal hashing

// fast calculation of (n modulo mersenne_prime)
long long fastMersenneModulo(const long long n) {
    return n & mersenne_prime;
}

// definition of the template hash function class
template <typename KeyType>
class HashFunc {
  public:
    long long univHash(const KeyType key, const long long table_size) const;
};

// the hash function class that supports the hashing of the "long long" data type
template <>
class HashFunc<long long> {
  public:
    long long univHash(const long long key, const long long table_size) const {
        long long hv = fastMersenneModulo(static_cast<long long>(uh_param_a * key + uh_param_b));
        hv = hv % table_size;
        return hv;
    }
};

// the has function class that supports the hashing of the "std::string" data type
template <>
class HashFunc<std::string> {
  private:
    const int param_base = 37;      // the base used for inflating each character
  public:    
    long long univHash(const std::string& key, const long long table_size) const {
        long long hv = 0;
        for(size_t i = 0; i < key.length(); ++ i) {
            hv = param_base * hv + static_cast<long long>(key[i]);
        }
        hv = fastMersenneModulo(static_cast<long long>(uh_param_a * hv + uh_param_b));
        hv = hv % table_size;
        return hv;
    }
};

// definition of the template hashed object class
template <typename KeyType, typename ValueType>
class HashedObj {
  public:

    KeyType key;
    ValueType value;

    HashedObj() {
        return;
    }

    HashedObj(const KeyType& k, const ValueType& v) : key(k), value(v) {
        return;
    }
  
    HashedObj(KeyType && k, ValueType && v) : key(std::move(k)), value(std::move(v)) {
        return;
    }

    bool operator==(const HashedObj<KeyType, ValueType>& rhs) {
        return (key == rhs.key);
    }    

    bool operator!=(const HashedObj<KeyType, ValueType>& rhs) {
        return !(*this == rhs);
    }   

};

template <typename KeyType, typename ValueType>
class MyHashTable { 
  private:
    size_t theSize; // the number of data elements stored in the hash table
    MyVector<MyLinkedList<HashedObj<KeyType, ValueType> >* > hash_table;    // the hash table implementing the separate chaining approach
    MyVector<size_t> primes;    // a set of precomputed and sorted prime numbers

    // pre-calculate a set of primes using the sieve of Eratosthenes algorithm
    // will be called if table doubling requires a larger prime number for table size
    // expected to update the private member "primes"
    void preCalPrimes(const size_t n) {
        primes.clear();
        std::vector<bool> is_prime(n + 1, true);
        for (size_t p = 2; p * p <= n; ++p) {
            if (is_prime[p]) {
                for (size_t i = p * p; i <= n; i += p) {
                    is_prime[i] = false;
                }
            }
        }
        for (size_t i = 2; i <= n; ++i) {
            if (is_prime[i]) {
                primes.push_back(i);
            }
        }
    }
    // finding the smallest prime that is larger than or equal to n
    // should perform binary search against the private member "primes"
    size_t nextPrime(const size_t n) {
        if (primes.back() < n) {
            preCalPrimes(n * 2);
        }
        return *std::lower_bound(primes.begin(), primes.end(), n);
    }
    // finds the MyLinkedList itertor that corresponds to the hashed object that has the specified key
    // returns the end() iterator if not found
    typename MyLinkedList<HashedObj<KeyType, ValueType> >::iterator find(const KeyType& key) {
        size_t hash_index = HashFunc<KeyType>().univHash(key, hash_table.size());
        auto& list = *hash_table[hash_index];
        return std::find_if(list.begin(), list.end(), [&key](const HashedObj<KeyType, ValueType>& obj) { return obj.key == key; });
    }

    // rehashes all data elements in the hash table into a new hash table with new_size
    // note that the new_size can be either smaller or larger than the existing size

    void rehash(const size_t new_size) {
        MyVector<MyLinkedList<HashedObj<KeyType, ValueType> >* > new_table(new_size);
        for (size_t i = 0; i < new_size; ++i) {
            new_table[i] = new MyLinkedList<HashedObj<KeyType, ValueType> >();
        }

        for (auto& list_ptr : hash_table) {
            for (const auto& obj : *list_ptr) {
                size_t new_index = HashFunc<KeyType>().univHash(obj.key, new_size);
                new_table[new_index]->push_back(obj);
            }
            delete list_ptr;
        }

        hash_table = std::move(new_table);
    }

    // doubles the size of the table and perform rehashing
    // the new table size should be the smallest prime that is larger than the expected new table size (double of the old size)
    void doubleTable() {
        size_t new_size = nextPrime(2 * hash_table.size());
        this->rehash(new_size);
        return;
    }

    // halves the size of the table and perform rehahsing
    // the new table size should be the smallest prime that is larger than the expected new table size (half of the old size)
    void halveTable() {
        size_t new_size = nextPrime(ceil(hash_table.size() / 2));
        this->rehash(new_size);
        return;
    }

  public:

    // the default constructor; allocate memory if necessary
    explicit MyHashTable(const size_t init_size = 3) : theSize(0), hash_table(init_size), primes() {
        for (size_t i = 0; i < init_size; ++i) {
            hash_table[i] = new MyLinkedList<HashedObj<KeyType, ValueType> >();
        }
        preCalPrimes(init_size * 2);
    }

    // the default destructor; collect memory if necessary
    ~MyHashTable() {
        for (auto& list_ptr : hash_table) {
            delete list_ptr;
        }
    }

    // checks if the hash tabel contains the given key
    bool contains(const KeyType& key) {
        return find(key) != hash_table[HashFunc<KeyType>().univHash(key, hash_table.size())]->end();
    }
    // retrieves the data element that has the specified key
    // returns true if the key is contained in the hash table
    // return false otherwise
    bool retrieve(const KeyType& key, HashedObj<KeyType, ValueType>& data) {
        auto it = find(key);
        if (it != hash_table[HashFunc<KeyType>().univHash(key, hash_table.size())]->end()) {
            data = *it;
            return true;
        }
        return false;
    }
    // inserts the given data element into the hash table (copy)
    // returns true if the key is not contained in the hash table
    // return false otherwise
    bool insert(const HashedObj<KeyType, ValueType>& x) {
        if (contains(x.key)) {
            return false;
        }
        if (theSize >= hash_table.size()) {
            doubleTable();
        }
        size_t index = HashFunc<KeyType>().univHash(x.key, hash_table.size());
        hash_table[index]->push_back(x);
        ++theSize;
        return true;
    }
    // inserts the given data element into the hash table (move)
    // returns true if the key is not contained in the hash table
    // return false otherwise
    bool insert(HashedObj<KeyType, ValueType> && x) {
        if (contains(x.key)) {
            return false;
        }
        if (theSize >= hash_table.size()) {
            doubleTable();
        }
        size_t index = HashFunc<KeyType>().univHash(x.key, hash_table.size());
        hash_table[index]->push_back(std::move(x));
        ++theSize;
        return true;
    }
    // removes the data element that has the key from the hash table
    // returns true if the key is contained in the hash table
    // returns false otherwise
    bool remove(const KeyType& key) {
        size_t index = HashFunc<KeyType>().univHash(key, hash_table.size());
        auto it = find(key);
        if (it == hash_table[index]->end()) {
            return false;
        }
        hash_table[index]->erase(it);
        --theSize;

        if (theSize * 4 < hash_table.size() && hash_table.size() > 3) {
            halveTable();
        }
        return true;
    }

    // returns the number of data elements stored in the hash table
    size_t size() {
        return theSize;
    }

    // returns the capacity of the hash table
    size_t capacity() {
        return hash_table.size();
    }

};

#endif // __MYHASHTABLE_H__
